google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawChart);
google.charts.setOnLoadCallback(drawMig);
 
 // population chart //
 function drawChart() {
     var queryStringPop = encodeURIComponent('SELECT A, B, LIMIT 26');

      var queryPop = new google.visualization.Query(
          'https://docs.google.com/spreadsheets/d/1JGc8FkQktCjqMQ9Ih_Sas9bghOKJqAe0hrbSBmFiH2c/edit?usp=sharing' + queryStringPop);
      queryPop.send(handleQueryPopResponse);
    }

    function handleQueryPopResponse(response) {
      if (response.isError()) {
        alert('Error in query: ' + response.getMessage() + ' ' + response.getDetailedMessage());
        return;
      }
			  var options = {
			  	width: 1500,
			  	height: 600
			  };

      var data = response.getDataTable();
      var chart = new google.visualization.ColumnChart(document.getElementById('chart_pop'));
      chart.draw(data, options);
    }


//migration chart//
	function drawMig() {
	var queryStringMig = encodeURIComponent('SELECT A, B, C, D, LIMIT 26');

	var queryMig = new google.visualization.Query(
  'https://docs.google.com/spreadsheets/d/1tXFcx-1ivZK_h60l4DV2DL3dqKpLQrFJ3yOcWGjO68Y/edit?usp=sharing' + queryStringMig);
	queryMig.send(handleQueryMigResponse);
}

function handleQueryMigResponse(response) {
	if (response.isError()) {
alert('Error in query: ' + response.getMessage() + ' ' + response.getDetailedMessage());
return;
}
  var options2 = {
  	width: 1500,
  	height: 600
  };

var data2 = response.getDataTable();
var chart2 = new google.visualization.ColumnChart(document.getElementById('chart_mig'));
chart2.draw(data2, options2);
}

// This was to test that all information from the datasheet was coming into the page correctly.
// var dataURL = 'https://docs.google.com/spreadsheets/d/1tXFcx-1ivZK_h60l4DV2DL3dqKpLQrFJ3yOcWGjO68Y/edit?usp=sharing';
//   function init() {
//     Tabletop.init( { key: dataURL,
//                      callback: showInfo,
//                      simpleSheet: true } )
//   }

//   function showInfo(data, tabletop) {
//     //alert('Successfully processed!')
//     console.log(data);

//     			var city = document.querySelector(".city");
// 					console.log(city);
// 				var migIn = document.querySelector(".mig-in");
// 					console.log(migIn);
// 				var migOut = document.querySelector(".mig-out");
// 					console.log(migOut);
// 				var netMig = document.querySelector(".net-mig");
// 					console.log(netMig);

// 				data.forEach(function(data){
// 					city.innerHTML += data.City;
// 					migIn.innerHTML += data.Moved_In;
// 					migOut.innerHTML += data.Moved_Out;
// 					netMig.innerHTML += data.Net_Migration;
// 				})
//   }

//   window.addEventListener('DOMContentLoaded', init);